<?php
/**
 * Yandex map
 * (код создан в конструкторе Яндекс.Карты)
 *
 */
?>

<script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Ab78a600cce8f2f66a1b6363afa67bad32ac174df93e0a6222315d57014e77f8d&amp;width=100%25&amp;height=450&amp;lang=ru_RU&amp;scroll=true"></script>

	


