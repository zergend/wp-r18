<div class="site-search">
  <form action="/" method="get" class="site-search__form">
      <input name="s" placeholder="Поиск по сайту" title="Введите поисковый запрос" type="search" required>
      <button type="submit"></button>
  </form>
</div>
